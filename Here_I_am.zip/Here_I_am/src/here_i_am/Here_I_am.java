/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package here_i_am;

/**
 *
 * @author sibby
 */
public class Here_I_am {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Login().setVisible(true);
        
        // TODO code application logic here
    }
    
}
